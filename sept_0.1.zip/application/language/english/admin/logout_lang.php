<?php
$lang['logout_success']		= 'You have been successfully logged out!';