<?php 
$lang['add_faq_categories']	       	= 'Add Faq Categories';
$lang['add_faq']	            	= 'Add Faq';
$lang['add_faq_category']	       	= 'Add Faq Category';
$lang['view_faq_categories']	    = 'View Faq Categories';
$lang['question']	            	= 'Question';
$lang['answer']	       				= 'Answer';
$lang['created']	   			    = 'Created';
$lang['action']	   					= 'Action';
$lang['faq_category_name']	   		= 'Faq category name';
$lang['faq_category_name_unique']	= 'Faq category name should be unique';
$lang['view_faq_categories']		= 'Faq Categories';
$lang['faq_category']	   			= 'Faq category';
$lang['select_category']	   		= 'Select category';
$lang['Is frequently asked question?']='Is frequently asked question?';
$lang['Yes']='Yes';
$lang['Submit']='Submit';
