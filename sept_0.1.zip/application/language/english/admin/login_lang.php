<?php
$lang['username']			= 'User Name';
$lang['password']			= 'Password';
$lang['login']				= 'Log In';
$lang['Edit Admin']			= 'Edit Admin';
$lang['With Selected']		= 'With Selected :';
$lang['Id']		            = 'Id';
$lang['Add Admin']		    = 'Add Admin';
$lang['Search Admin']		= 'Search Admin';
$lang['Enter the Admin Id']	= 'Enter the Admin Id';

$lang['login_failed']		= 'Log Failed.Username and password do not match.';