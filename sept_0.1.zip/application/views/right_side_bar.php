<!-- Side bar -->
<div id="Side_Bar" class="clsFloatRight">
    <div class="clsSide_Add">
        <a href="#"><img src="<?php echo base_url()?>images/add.png" alt="image" /></a>
    </div>
    <div class="clsFace_Likers">
    	<?php
        	echo fan_box();
		?>
        
    </div>
</div>
<style type="text/css">
.connect_widget
{
	background-color:#F1F5F2 !important;
}
</style>
<!-- End of Side Bar -->